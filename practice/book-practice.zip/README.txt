Python で学ぶデータ分析：第 1〜15 章の講義と実習

ZIP を展開し，ノートブックと CSV を同じフォルダーに置いてください。
最初は 00_environment.ipynb を開き，上から順にセルを実行します。
第 4 章のファイル名は flight-rankings.ipynb です。
各回のノートは，講義に沿って実行する前半と，自分で条件を変えて調べる後半の演習で構成しています。

Colab：サポートページの「Colab で開く」から開き，「ドライブにコピーを保存」して実行します。
CSV は準備セルが公開 URL から読み込みます。同じフォルダーにある CSV を優先します。
サポートページ：https://github.com/sohei-takagi/python-ds-course-materials
Positron：Python のプロジェクトを作り，その環境をノートブックのカーネルに選びます。
必要なパッケージの版は requirements.txt，準備の詳細は Book の「Python と学習環境」を参照してください。

元データの説明は flight-data-sources.md，ssdse-sources.md，census-sources.md，penguins-sources.md，mosquito-sources.md，bike-sharing-sources.md，jma-temperature-sources.md にあります。
SSDSE の公式解説は ssdse-a-2026-guide.pdf に同梱しています。
配布元：https://www.nstac.go.jp/files/kaisetsu-A-2026.pdf
実習では数値とともに対象，時期，指標の定義を確認してください。
